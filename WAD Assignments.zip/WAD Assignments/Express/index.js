const express = require('express');
const app = express();
const port = 3400;

//to make pages .html .txt .jpeg .mp3 .mp4  static content 
app.use(express.static("dashboard"));

app.listen(port, () => {
    console.log(`app started on port ${port}`);
})